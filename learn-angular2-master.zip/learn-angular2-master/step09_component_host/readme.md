In Angular 2, a component host is the element that component is attached to.

To say it in another way, to turn an Angular component into something rendered in the DOM you have to associate an Angular component with a DOM element. We call such elements host elements.

A component can interact with its host DOM element in the following ways: It can listen to its events. It can update its properties. It can invoke methods on it.

http://victorsavkin.com/post/118372404541/the-core-concepts-of-angular-2

Chapter 1 pages 30-31 ng-book 2: https://www.ng-book.com/2/

http://stackoverflow.com/questions/34881401/style-html-body-from-web-component-angular-2

