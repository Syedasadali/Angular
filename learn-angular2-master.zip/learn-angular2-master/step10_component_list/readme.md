Chapter 1 and section "Storing multiple Articles" on pages 42-48 ng-book 2: https://www.ng-book.com/2/


