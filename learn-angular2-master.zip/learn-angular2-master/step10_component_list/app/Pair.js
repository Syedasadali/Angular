"use strict";
var Pair = (function () {
    function Pair(name, value) {
        this.name = name;
        this.value = value;
    }
    return Pair;
}());
exports.Pair = Pair;
//# sourceMappingURL=Pair.js.map