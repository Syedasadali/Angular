import {Component} from '@angular/core';

@Component({
    selector: 'child-one',
    template: `<div>This is child One</div>`
})
export class ChildOneComponent { 

    constructor() {
     
    }
}