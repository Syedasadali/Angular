# Learn Angular 2 in Baby Steps
We will learn Angular 2 by taking small incremental steps. But before we start with Angular 2 we will first have to learn TypeScript and Reactive Programming:

https://github.com/panacloud/learn-typescript

https://github.com/panacloud/learn-typed-rxjs


We will be using VSCode as our Editor, just open the project file in VSCode. Read the readme.md file in each project.

Install VS Code Editor: https://code.visualstudio.com/

For questions and discussion join: https://www.facebook.com/groups/angular2/

If you also want to learn React at the same time, every step here is mirrored in this repo:

https://github.com/panacloud/learn-react








