Read:

https://angular.io/docs/ts/latest/guide/webpack.html

Watch:

https://www.youtube.com/watch?v=j9w5hFit5rM