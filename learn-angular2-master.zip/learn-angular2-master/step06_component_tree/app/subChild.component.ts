import {Component} from '@angular/core';

@Component({
    selector: 'sub-child',
    template: `<div>This is sub child component</div>`
})
export class SubChildComponent { 

    constructor() {
     
    }
}