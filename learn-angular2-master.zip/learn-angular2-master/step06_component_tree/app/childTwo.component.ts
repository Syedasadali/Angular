import {Component} from '@angular/core';

@Component({
    selector: 'child-two',
    template: `<div>This is child Two</div>`
})
export class ChildTwoComponent { 

    constructor() {
     
    }
}