From: https://angular.io/cheatsheet


Chapter 1 pages 46 ng-book 2: https://www.ng-book.com/2/