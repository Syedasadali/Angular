We will use ng-book 2 to learn: https://www.ng-book.com/2/

Chapter 1 pages 18-21