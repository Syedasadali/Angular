Read:

https://angular.io/docs/ts/latest/guide/forms.html

Forms in Angular 2 Chapter of ng-book 2:

https://www.ng-book.com/2/