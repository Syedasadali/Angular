Chapter 1 pages 42-45 ng-book 2: https://www.ng-book.com/2/

https://angular.io/docs/ts/latest/guide/template-syntax.html#!#inputs-outputs