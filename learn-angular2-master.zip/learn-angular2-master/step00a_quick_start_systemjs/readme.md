We are starting to learn Angular 2, the assumption is that you have a basic understanding of TypeScript.
If you do not know TypeScript please go to:

https://github.com/panacloud/learn-typescript

Install VS Code Editor:
https://code.visualstudio.com/

We will start with this quick start.
https://angular.io/docs/ts/latest/quickstart.html

For questions and discussion join:
https://www.facebook.com/groups/angular2/