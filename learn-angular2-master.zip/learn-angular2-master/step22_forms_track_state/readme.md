Read:

https://angular.io/docs/ts/latest/guide/forms.html

Forms in Angular 2 Chapter of ng-book 2:

https://www.ng-book.com/2/

Now run the app and focus on the Name input box. Follow the next four steps precisely

Look but don't touch

Click in the input box, then click outside the text input box

Add slashes to the end of the name

Erase the name