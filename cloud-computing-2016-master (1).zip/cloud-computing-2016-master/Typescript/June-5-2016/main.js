// let myType = {name: "taha", age: 10};
// // myType = {name: "zia", age: 10, gender: true};
// let myType2 = {name: "shahid", age: 100, id: 10};
// myType = myType2;
// console.log(myType.name);
// 
// let arr : Array<number> = new number[2];
// let a : number = 5;
// let b : any = 9;
if (true) {
    var a = 10;
    if (true) {
        var a_1 = 20;
        console.log(a_1);
    }
}
