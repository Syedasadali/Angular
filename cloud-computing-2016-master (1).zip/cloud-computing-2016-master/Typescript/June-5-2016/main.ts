// let myType = {name: "taha", age: 10};
// // myType = {name: "zia", age: 10, gender: true};
// let myType2 = {name: "shahid", age: 100, id: 10};
// myType = myType2;
// console.log(myType.name); //warning
// 

// let myType: {foo: number, bar?: number};

//let array : number[] = [];
// let arr : Array<number> = new number[2]; //error 

// let a : number = 5;
// let b : any = 9;


// if(true){
//     let a = 10;
//     if(true){
//         let a = 20
//         console.log(a)
//     }
// }

// let myType : any= <any> { name: "Zia", id: 1 };



