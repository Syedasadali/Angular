
// enum Color {Red, Grenn, Blue};
// var color: Color = Color.Red;
// if(color == Color.Red){
    // 
// }


// enum Color {Red = 2, Green, Blue};
// var color : Color = Color.Blue; 
// console.log(color);


// enum Color {Red, Green, Blue};
// var color : Color = Color.Blue; 
// console.log(Color[0]);


// var food = makeChickenTikka(1000);
// function makeChickenTikka(money : number) : string{
//     console.log('hello');
//     return "chickenTikka";
// }


// var a : number = 5;
// var f : (xyz : number) => string = function (money : number) : string{
//     console.log('hello');
//     return "chickenTikka";
// }
// var food : string = f(1000);


// var sum = function(x: number, y: number): number{
//     return x + y;
// }
// var sum2 = (x:number, y: number) => x + y;
// sum2(10, 20)



// var sum = function(x: number, y: number): number{
//     return x + y;
// }
// var sum2 = (x:string, y?: string) => x + y;
// console.log(sum2(10))


// var sum = function(x: number, y: number): number{
//     return x + y;
// }
// var sum2 = (x?:string, y?: string) => x + y;
// console.log(sum2("10"))


// enum operator {sum, minus};
// function xyz(opr: string, x:number, y:number){
//     if(operator[opr])
// }


// var f : (x, number) => number;

// f = function(x:string){
//     return x
// }
