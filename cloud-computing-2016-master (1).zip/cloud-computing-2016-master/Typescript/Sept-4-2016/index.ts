export function add(a, b) {
    return a + b;
}
function sub(a, b) {
    return a - b;
}

export default function calc() {
    
}

// add(5, 10);
console.log('hello')