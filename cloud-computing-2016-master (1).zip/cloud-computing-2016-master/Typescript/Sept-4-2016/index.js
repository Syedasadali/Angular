"use strict";
function add(a, b) {
    return a + b;
}
exports.add = add;
function sub(a, b) {
    return a - b;
}
function calc() {
}
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = calc;
// add(5, 10);
console.log('hello');
