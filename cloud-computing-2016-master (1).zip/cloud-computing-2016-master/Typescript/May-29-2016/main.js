// alert(a); //throw error


// alert(a); //undefined
// var a = 10;

// alert(a); //undefined
// var a = 10;
// alert(a) //10