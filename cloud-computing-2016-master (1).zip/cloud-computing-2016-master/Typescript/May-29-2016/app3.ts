// const a = 5;
// a = 10

// const a : number = 10;

if(true){
    const a = 10;
   
}
alert(a);