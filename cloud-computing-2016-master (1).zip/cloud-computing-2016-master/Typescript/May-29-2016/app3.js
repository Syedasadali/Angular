// const a = 5;
// a = 10
// const a : number = 10;
if (true) {
    var a = 10;
}
alert(a);
