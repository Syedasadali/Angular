if (true) {
    var a = 10;
    alert(a);
}
alert(a);
