# Learn Angular 2 in Baby Steps
We will learn Angular 2 by taking small incremental steps. But before we start with Angular 2 we will first have to learn TypeScript and Reactive Programming:

https://github.com/tahashahid/cloud-computing-2016/tree/master/Typescript


We will be using VSCode as our Editor, just open the project file in VSCode. 

Run following commands on terminal

```bash
$ npm install
$ typings install
```

To run server run this command on terminal

```bash
$ npm start
```
#####OR

```bash
$ npm lite
```


Install VS Code Editor: https://code.visualstudio.com/

For questions and discussion join: https://www.facebook.com/groups/angular2/






